import pandas as pd

df = pd.read_csv("sales_data.csv", encoding="latin1")

print("Dataset Loaded Successfully!")
print(df.head())
print(df.shape)
print(df.columns)
print(df.isnull().sum())

df.dropna(inplace=True)

print(df.duplicated().sum())
df.drop_duplicates(inplace=True)
print("Total Sales:", df["Sales"].sum())
print("Total Profit:", df["Profit"].sum())
print(df.groupby("Category")["Sales"].sum().sort_values(ascending=False))
print(df.groupby("Category")["Profit"].sum().sort_values(ascending=False))
import matplotlib.pyplot as plt

sales = df.groupby("Category")["Sales"].sum()

import matplotlib.pyplot as plt

sales = df.groupby("Category")["Sales"].sum()

colors = ["#4E79A7", "#F28E2B", "#59A14F"]

plt.figure(figsize=(8, 8))

plt.pie(
    sales,
    labels=sales.index,
    autopct="%1.1f%%",
    startangle=90,
    colors=colors,
    explode=[0.05, 0.05, 0.05],
    shadow=True
)

plt.title(
    "Sales Distribution by Category",
    fontsize=16,
    fontweight="bold"
)

plt.axis("equal")
plt.show()
profit = df.groupby("Category")["Profit"].sum()
profit.plot(kind="bar")
plt.title("Profit by Category")
plt.show()
df["Order Date"] = pd.to_datetime(df["Order Date"])

monthly_sales = df.groupby(df["Order Date"].dt.month)["Sales"].sum()

monthly_sales.plot(marker="o")
plt.title("Monthly Sales Trend")
plt.show()